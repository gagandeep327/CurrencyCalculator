function converter(){
    var Money = parseInt(document.getElementById('Currency').value);
    var Convertion = document.getElementById('convert').value;
    var Dollar = document.getElementById('Dollar12');
    if(Convertion  == 1){
        Dollar.value = Money  * 110.76;
        Dollar.type = "text";
    }
    if(Convertion  == 2){
        Dollar.value = Money  * 64.35;
        Dollar.type = "text";
    }
    if(Convertion  == 3){
        Dollar.value = Money  * 0.82;
        Dollar.type = "text";
    }
    if(Convertion  == 4){
        Dollar.value = Money  * 0.72;
        Dollar.type = "text";
    }
    if(Convertion  == 5){
        Dollar.value = Money  * 108.58;
        Dollar.type = "text";
    }
    if(Convertion  == 6){
        Dollar.value = Money  * 1.26;
        Dollar.type = "text";
    }

  }
  function SeasonIS()
  {
      var see = prompt("Season is : ");
      if (see == "Summer"){
          document.getElementById('Send').innerHTML="Output : "+see;
      }
      else if (see == "Winter"){
          document.getElementById('Send').innerHTML="Output : "+see;
      }
      else if (see == "Spring"){
          document.getElementById('Send').innerHTML="Output : "+see;
      }
      else {
          document.getElementById('Send').innerHTML="Enter Valid One";
      }
  }